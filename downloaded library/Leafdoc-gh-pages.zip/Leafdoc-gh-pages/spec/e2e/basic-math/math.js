// 🍂class Math
// 🍂function rand(): Number
// Returns a random number between 0.0 and 1.0
export function rand() {
	// Do something here.
}

// 🍂function log(x: Number): Number
// Returns the natural logarithm (base e) of the given number
export function log(x) {
	// Do something
}
