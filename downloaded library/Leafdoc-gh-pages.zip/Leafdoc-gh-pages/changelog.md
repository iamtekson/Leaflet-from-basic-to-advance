
# 1.5.1 (2019-01-30)

* Fixed --character argument for command-line utility.


# 1.4.0

* Documentables have an `optional` flag
* Documentables can be defined as inheritable or not
* Added a `getTemplateEngine` to override the default handlebars helpers
* Cached the compiled templates




